// netlify/functions/redirect.js
export async function handler(event, context) {
  try {
    const { getStore } = await import("@netlify/blobs");

    // get slug from /r/<slug>
    let slug = null;
    if (event.path) {
      slug = event.path.replace(/^\/r\//, "").replace(/^\/+/, "");
    }
    if (!slug && event.queryStringParameters && event.queryStringParameters.splat) {
      slug = event.queryStringParameters.splat;
    }

    if (!slug) {
      return { statusCode: 400, body: "Missing slug" };
    }

    const storeName = process.env.NETLIFY_BLOBS_STORE ? process.env.NETLIFY_BLOBS_STORE : "default";
    const store = getStore({ name: storeName });

    const key = `dl:${slug}`;
    const val = await store.get(key);

    if (!val) {
      return {
        statusCode: 404,
        body: `No dynamic link found for slug: ${slug} (store: ${storeName})`,
      };
    }

    const record = JSON.parse(val);
    record.clicks = (record.clicks || 0) + 1;
    record.updated = Date.now();

    await store.set(key, JSON.stringify(record), {
      metadata: { updated: new Date().toISOString() },
    });

    // log scan
    const ts = Date.now();
    const scanEvent = {
      ts,
      slug,
      destination: record.destination,
      ua: event.headers["user-agent"] || "",
      referer: event.headers["referer"] || "",
    };
    await store.set(`scan:${slug}:${ts}`, JSON.stringify(scanEvent));
    await store.set(`scan:last:${slug}`, JSON.stringify(scanEvent));

    if (!record.destination) {
      return { statusCode: 500, body: "Dynamic link missing destination" };
    }

    return {
      statusCode: 302,
      headers: {
        Location: record.destination,
      },
      body: "",
    };
  } catch (err) {
    console.error("redirect error", err);
    return {
      statusCode: 500,
      body: "Redirect function error",
    };
  }
}
